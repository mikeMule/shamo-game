"""
SHAMO Telegram Bot
==================
- /start  → asks user to share phone number
- Contact → registers user, sends Mini App launch button
- /play   → sends Mini App button directly (for already-registered users)
- /help   → shows help

Setup:
  1. Copy .env.example to .env and fill in your token
  2. Host index.html on HTTPS (e.g. Hostinger VPS with nginx)
  3. Set SHAMO_WEBAPP_URL to your hosted URL
  4. Run:  python bot.py
"""

import logging
import os
import json
import hmac
import hashlib
from urllib.parse import parse_qsl

from telegram import (
    Update,
    KeyboardButton,
    ReplyKeyboardMarkup,
    ReplyKeyboardRemove,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    WebAppInfo,
)
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    ContextTypes,
    filters,
)


# ─── Logging ───────────────────────────────────────────────
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)


# ─── .env loader (no external deps) ───────────────────────
def load_dotenv(path: str = ".env") -> None:
    try:
        with open(path, "r", encoding="utf-8") as f:
            for raw in f:
                line = raw.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, value = line.split("=", 1)
                key = key.strip()
                value = value.strip().strip('"').strip("'")
                if key:
                    os.environ.setdefault(key, value)
    except FileNotFoundError:
        pass


# ─── Telegram initData validator ───────────────────────────
def validate_init_data(init_data: str, bot_token: str) -> bool:
    """
    Validates Telegram WebApp initData to confirm the user is real.
    Call this on your backend when the Mini App sends data for claiming prizes.
    """
    try:
        parsed = dict(parse_qsl(init_data, keep_blank_values=True))
        received_hash = parsed.pop("hash", None)
        if not received_hash:
            return False

        data_check_string = "\n".join(
            f"{k}={v}" for k, v in sorted(parsed.items())
        )
        secret_key = hmac.new(
            b"WebAppData", bot_token.encode(), hashlib.sha256
        ).digest()
        expected_hash = hmac.new(
            secret_key, data_check_string.encode(), hashlib.sha256
        ).hexdigest()

        return hmac.compare_digest(received_hash, expected_hash)
    except Exception as e:
        logger.error("init_data validation error: %s", e)
        return False


# ─── Config ────────────────────────────────────────────────
load_dotenv()
BOT_TOKEN       = os.getenv("TELEGRAM_BOT_TOKEN", "")
# ⚠️  Replace with your real hosted HTTPS URL after deploying index.html
SHAMO_WEBAPP_URL = os.getenv("SHAMO_WEBAPP_URL", "https://your-domain.com/shamo/")


def _webapp_keyboard() -> InlineKeyboardMarkup:
    """Inline button that opens the SHAMO Mini App."""
    return InlineKeyboardMarkup([[
        InlineKeyboardButton(
            text="🎮 Play SHAMO",
            web_app=WebAppInfo(url=SHAMO_WEBAPP_URL),
        )
    ]])


# ─── Handlers ──────────────────────────────────────────────

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """/start — welcome message + phone-share button."""
    user = update.effective_user
    chat_id = update.effective_chat.id

    keyboard = ReplyKeyboardMarkup(
        [[KeyboardButton(text="📱 Share my phone number", request_contact=True)]],
        resize_keyboard=True,
        one_time_keyboard=True,
    )

    await context.bot.send_message(
        chat_id=chat_id,
        text=(
            f"👋 Welcome to *SHAMO*, {user.first_name}! ሻሞ 🎯\n\n"
            "Answer 3 Ethiopian culture questions, spin the wheel and win prizes!\n\n"
            "📱 First, please share your phone number to register."
        ),
        reply_markup=keyboard,
        parse_mode="Markdown",
    )


async def contact_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Receives phone contact → registers user → sends Mini App button."""
    if not update.effective_contact:
        return

    contact = update.effective_contact
    user    = update.effective_user
    chat_id = update.effective_chat.id

    phone     = contact.phone_number
    user_id   = user.id
    username  = user.username or ""
    full_name = (user.first_name or "") + (" " + user.last_name if user.last_name else "")

    # ── TODO: Store in your DB (Supabase) ──────────────────
    # Example with supabase-py:
    #   from supabase import create_client
    #   sb = create_client(SUPABASE_URL, SUPABASE_KEY)
    #   sb.table("players").upsert({
    #       "tg_user_id": user_id,
    #       "phone":      phone,
    #       "username":   username,
    #       "full_name":  full_name,
    #   }).execute()
    # ────────────────────────────────────────────────────────

    logger.info(
        "Registered user: id=%s name=%s username=%s phone=%s",
        user_id, full_name, username, phone,
    )

    # Remove the phone-share keyboard, then send Mini App button
    await context.bot.send_message(
        chat_id=chat_id,
        text="✅ You're registered! Tap below to open SHAMO and start playing 🎡",
        reply_markup=ReplyKeyboardRemove(),
    )

    await context.bot.send_message(
        chat_id=chat_id,
        text=(
            "🏆 *SHAMO Prize Game* ሻሞ\n\n"
            "• Answer 3 Ethiopian culture questions ❓\n"
            "• Spin the wheel to win up to *$5.00* 🎡\n"
            "• Prizes paid instantly via Chapa 💳\n\n"
            "_All 3 answers must be correct to unlock your spin!_"
        ),
        reply_markup=_webapp_keyboard(),
        parse_mode="Markdown",
    )


async def play_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """/play — quick shortcut to open the Mini App."""
    await update.message.reply_text(
        text="🎮 Open SHAMO now 👇",
        reply_markup=_webapp_keyboard(),
    )


async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """/help — list available commands."""
    await update.message.reply_text(
        "📋 *SHAMO Commands*\n\n"
        "/start — register with your phone & get game link\n"
        "/play  — open the SHAMO Mini App directly\n"
        "/help  — show this message\n\n"
        "🌐 Game URL: " + SHAMO_WEBAPP_URL,
        parse_mode="Markdown",
    )


async def unknown_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text("❓ Unknown command. Try /help")


# ─── Main ──────────────────────────────────────────────────

def main() -> None:
    if not BOT_TOKEN:
        raise RuntimeError(
            "Missing TELEGRAM_BOT_TOKEN.\n"
            "Add it to .env:  TELEGRAM_BOT_TOKEN=your_token_here"
        )

    app = Application.builder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start",  start))
    app.add_handler(CommandHandler("play",   play_cmd))
    app.add_handler(CommandHandler("help",   help_cmd))
    app.add_handler(MessageHandler(filters.CONTACT, contact_handler))
    app.add_handler(MessageHandler(filters.COMMAND, unknown_cmd))

    logger.info("SHAMO bot starting… Mini App URL: %s", SHAMO_WEBAPP_URL)
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
